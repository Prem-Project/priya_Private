package Java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import org.knowm.xchart.internal.chartpart.Chart;

public class programs2 {

	public static  void main(String[] args) {
		
	//String Reversal 	                 
		/*
		
		String st="priya";
		String rev=" ";
		
		for(int i=st.length()-1; i>=0;i--)
         {
              rev= rev+st.charAt(i);
	                 
         }       
		System.out.println(rev);
	                 
	           
		
		//String reversal 
		
		String st="priya";
		StringBuffer input = new StringBuffer(st);
		input.reverse();
		System.out.println(input);      
		
		//String Duplicates
		
		String st ="priyanka";
		 char[] ch=st.toCharArray();
		 int count=0;
		 for(int i=0;i<ch.length;i++) {
			 for(int j=i+1; j<ch.length;j++) {
				 if(ch[i]==ch[j])
				 {
					System.out.println(ch[i]); 
					count++;
				 }
			 }
		 }
		 System.out.println(count); 
		
		//array Duplicates
		
		int a[] = {2,2,3,4,4,5,5,6};
		for(int i=0 ; i<a.length;i++)
		{
			for(int j=i+1; j<a.length; j++)
			{
				if(a[i] ==a[j])
				{
					System.out.println(a[i]);
				}
			}
		}            
		
		//conact 
		
		String s1="priya";
		String s2="prii";
		String s3=s1.concat(s2);
		System.out.println(s3);
		
		
		//array reverse 
		
		int a[] = {2,3,4,5,6,7,8,9,11};
		for(int i=a.length-1;i>=0; i--) {
			System.out.println(a[i]);
		}
		
		
		//unique array 
		
		int a []= {2,3,3,3,3,4,4,4,4};
		HashMap<Integer , Integer> map = new HashMap<>();
		for(int i=0 ; i<a.length;i++)
		{
			map.put(a[i],i);
		}
		System.out.println(map.keySet()); 
	
		//odd and even 
		
		int a[] = {2, 4, 6, 7, 8};
		int  even=0 ,odd=0;
		for(int i=0 ; i<a.length; i++)
		{
			if(a[i]%2==0)
			{
				System.out.println(a[i]);
				even++;
			}
			else
			{
				odd++;
			}
		}
		System.out.println(odd);
		System.out.println(even); 
		
		//lowercase and upper case 
		
		String st="pNKA";
		int upper=0,lower = 0;
		
		for(int i=0;i<st.length();i++) {
			char ch =st.charAt(i);
			if(ch>65 && ch<90)
			{
				upper++; 
			}
			else {
				lower++;
			}
		}
			
			System.out.println(upper);
			System.out.println(lower);  
		
		//vowels
		String st ="Priyanka";
		int count =0;
		for(int i=0 ; i<st.length();i++)
		{
			if(st.charAt(i)=='a' ||st.charAt(i)=='e' ||st.charAt(i)=='i' ||st.charAt(i)=='o' ||st.charAt(i)=='u')
				count ++;
		
				
		}
		System.out.println(count);   
		
		//swapping of two numbers
		String s1="priya";
		String s2= "papa";
	   
		s1= s1+s2;
		s2= s1.substring(0, (s1.length()-s2.length()));
		s1=s1.substring(s2.length());
		System.out.println(s1);
		System.out.println(s2); 
		
		int x=10 ; 
		int y=15;
		x=x+y;
		y=x-y;
		x=x-y;
		System.out.println(x);
		System.out.println(y);
		
		
		//anagram
		
		String s1="race";
		String s2="care";
		s1.toLowerCase();
		s2.toLowerCase();
		
		
		if(s1.length()!= s2.length()) {
			System.out.println("both are not anagram");
		}
		else {
			char[] ch1 = s1.toCharArray();
			char[] ch2=s2.toCharArray();
			Arrays.sort(ch1);
			Arrays.sort(ch2);
			
	 if(Arrays.equals(ch1,ch2) ==true)
	 {
		 System.out.println("both the given strings are Anagram");
	 }
	 
	 else {
		 System.out.println("Both the given Strings are not anagram");
	 }
			
		} 
		
		//palindrome
		
		int num=434;
		int temp =num;
		int rev=0;
		while(num>0)
		{
			int d= num%10;
			rev= rev*10+d;
			num = num/10;
		}
		
		if(temp==rev)
		{	                 
			System.out.println(temp);
		}
		else {          
			System.out.println(temp);
		}
	          */       
		
		//prime number 
		
		int num=10 ;
		
		int count;
		for(int i=0 ; i<=num ; i++) {
			count=0;
		
			for(int j=2; j<=i/2;j++) {
				
				if(i%j==0)
				{
					count++;
					break;
				}
				
			}
			
			if(count==0) {
				System.out.println(i);
			}
			
			
		}
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
                           
	                 
}
	}

