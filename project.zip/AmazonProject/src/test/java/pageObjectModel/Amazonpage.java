package pageObjectModel;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Amazonpage {

	@FindBy(id=("ap_email"))
	public static WebElement Emailormobilephonenumber;
	
	@FindBy(xpath="//*[@id='continue']")
	public static WebElement Continue;
	
	@FindBy(xpath="//*[@id='ap_password']")
	public static WebElement Password;
	
	@FindBy(xpath="//*[@id='signInSubmit']")
	public static WebElement Signin;	
	
	@FindBy(id="twotabsearchtextbox")
	public static WebElement searchBox;	
	
	

	}


