package TestRunner;

import org.junit.runner.RunWith;

import io.cucumber.junit.Cucumber;
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.CucumberOptions.SnippetType;

@RunWith(Cucumber.class)
@CucumberOptions(features={".//Featurefile./amazon.feature"}, glue={"StepDefinitions","Hooks"},
dryRun=!true,monochrome=true,snippets=SnippetType.CAMELCASE,publish=true,
plugin={"pretty","html:CucumberReports",
		"json:reports/result.json",
		"junit:reports/result.xml"})
 
public class testrun {


	}

//features={".//Featurefile./LoginDDTExcel.feature"},
//features={".//Featurefile./Login.feature" ,".//Featurefile./Registration.feature"},
//features={"@target/rerun.txt"},

//  plugin= {"pretty" , "html:reports/myreport.html" ,
		 //  "rerun:target/rerun.txt",
		//   "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"
		 //  },
//   dryRun=false,
//  monochrome=true,
//  publish=true,
//   tags="@sanity"  //this will execute scenarios tagged with @sanity
//  tags ="@regression" //
//tags="@sanity and "@regression" //sceanrios tagged with both @sanity and @regression 
//tags="@sanity and not "@regression"  //sceanrios tagged with @sanity and but not  @regression
//tags="@sanity or "@regression" //sceanrios tagged with either @sanity or @regression
/*
  @CucumberOptions (
		
		      
		       features={".//Featurefile./amazon.feature"},glue={"StepDefinitions", "Hooks"}
		       
                )
 */

