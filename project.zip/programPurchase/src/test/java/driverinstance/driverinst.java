package driverinstance;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class driverinst {

	        public static WebDriver driver;
			public static WebDriverWait wait;
		 
		

	}


