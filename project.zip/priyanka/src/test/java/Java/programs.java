package Java;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import org.knowm.xchart.internal.chartpart.Chart;

public class programs {

	public static  void main(String[] args) {
		
		//String Reversal
		
	/*	String s1="Priya";
		StringBuffer input = new StringBuffer(s1);
		input.reverse();
		System.out.println(input);

	} 
	
	//String reversal using StringBuilder Method
	
	String s2="Papa";
	StringBuilder input = new StringBuilder();
	input.append(s2);
	input.reverse();
	System.out.println(input); 
		
		//string reversal using scanner input method
		
		 
		  Scanner scanner = new Scanner(System.in);
	        String Str = scanner.nextLine();
	        char[] arr = Str.toCharArray();
	         String rev = "";
	   
	         for(int i = Str.length() - 1; i >= 0; i--)
	                 {
	                       rev = rev + Str.charAt(i);
	                  }
	  
	                 System.out.println(rev); 
		
		//cancat 3 strings
		
		String s1="Automation";
		String s2="Framework";
		String s3="Cucumber";
		String s4=s1.concat(s2).concat(s3);
		System.out.println(s4);  
		
		//Duplicates of an array
		
		int[] a= {10,20,10,20,30,50,58};
		for(int i=0; i<a.length;i++){
			{
				for(int j=i+1; j<a.length;j++)
				{
					if(a[i]==a[j])
					{
						System.out.println(a[i]);
					}
				}
			}
		}  
		
		// array reverse order
		
		int a[] = { 2,3,4,5,6,7,8};
		
		for(int i=a.length-1; i>=0;i--)
		{
			System.out.println(a[i]);
		} 
		
		//vowels count 
		
		String st="Priya";
		int count=0;
		for(int i=0; i<st.length();i++)
		{
			if(st.charAt(i)=='a' || st.charAt(i)=='e'|| st.charAt(i)=='i'||st.charAt(i)=='o'||st.charAt(i)=='u')
				count++;
		}
		System.out.println(count); 
		
		//vowels count using Arraylist
		
		
		String str = "Priyanka";
        int count = 0;
        String vow ="aeiou";
        ArrayList<Character> vowels = new ArrayList<Character>();
        for(int i=0;i<vow.length();i++)
        {
            vowels.add(vow.charAt(i));
        }
        for (int i = 0; i < str.length(); i++) {
            if(vowels.contains(str.charAt(i))){
                count++;
            }
        }
        System.out.println(count);  
		
	//	find odd and even nuber count
		int a[]= {23,14,6,7,9};
		int even=0 , odd=0;
		
		for(int i=0;i<a.length; i++) {
			
			if(a[i]% 2==0)
			{
				even++;
			}
			else
			{
				odd++;
			}
			
		}
			System.out.println(even);
			System.out.println(odd); 
		
		//string duplication
		
		String[] s1= {"priya" ,"papa" ,"Mylu"};
		String [] s2= {"priya" ,"papa"};
		HashSet<String> set= new HashSet<String>();
		
		for(int i=0;i<s1.length; i++)
		{
			for(int j=0;j<s2.length;j++)
			{
				if(s1[i].equals(s2[j]))
						{
					        set.add(s1[i]); 
						}
				{
					System.out.println(set);
				}
			}
		} 
		
		String s1="AutOMationFrameWork";
		int upper=0 , lower=0;
		
		for(int i=0;i<s1.length();i++)
		{
			char ch=s1.charAt(i);
			if(ch>=40 && ch<=90)
			{
				upper++;
			}
			lower++;
		}
		System.out.println(upper);
		System.out.println(lower); 
		
		//Arrays sort
		
		int a[]= {55,78,45,6,9};
		Arrays.sort(a);
		for(int v:a)
		{
			System.out.println(v);
		}
		System.out.println(a[0]); 
		
		int a=20; int b=30;
		int larger=(a>b)?a:b;
		System.out.println(larger); 
		
		//Swappig of two numbers
		 int x=10; int y=80;
		 x=x+y;
		 y=x-y;
		 x=x-y;
		 System.out.println(x);
		 System.out.println(y); 
		
		//string swapig
		String s1= "priya";
		String s2="automation";
		String temp=s1;
		s1=s2;
		s2=temp;
		System.out.println(s1);
		System.out.println(s2);
		
		//string duplicates 
		
		String str="Priyanka";
		int count=0;
		 char[] ch=str.toCharArray();
		for(int i=0;i<ch.length;i++) {
			for(int j=i+1;j<ch.length;j++) {
				if(ch[i]==ch[j]) {
					System.out.println("duplicate string are: " + ch[i]);
					count++;
					
				}
			}
		}
		System.out.println("duplicate string count :" +count); 
		
		//reverse a given array
		
		int a[]= {10,20,20,40,10};
		
		for(int i=a.length-1;i>=0;i--)
		{
			System.out.println(a[i]); 
			
		} 
		
		//array duplicates
		
		int a[]= {20,40,20,60, 30 ,60,10, 30, 60 ,10};
		int count=0;
		for(int i=0; i<a.length; i++) {
			for(int j=i+1;j<a.length; j++ ) {
				
			if(a[i]==a[j]) {
				System.out.println("duplicate arrays are: " + a[i]);
				count++;
			}
				
			}
		}
		
		System.out.println("duplicate arrays count :" +count); 
		
		//finding the unique array in a given array 
		
		int[] array= {2,4,6,7,4,4,3,3,3,8,9,2};
		HashMap<Integer,Integer> hashmap =new HashMap<Integer, Integer>();
		for(int i=0;i<array.length;i++)
		{
			hashmap.put(array[i], i);
		}
		System.out.println(hashmap.keySet()); 
		
		//to print a prime number 1 to 20
		
		int num=20;
		int count;
		for(int i=1;i<=num;i++) {
			count=0;
		
			for(int j=2;j<=i/2;j++)
			{
				if(i %j==0) {
					count++;
				break;
			}
		}
		
		if(count ==0) {
			System.out.println(i);
		}
	
		}	*/
		
		//palindrome or  not 
		int num=454;
		int temp=num;
		int rev=0;
		while(num>0) {
			int d=num%10;
			rev=rev*10 +d;
			num=num/10;
		}
		if(temp==rev) {
			System.out.println(temp +"is a palindrome");
		}
		
		
			
		
		
		
		
		
		
		
		
		
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
	                 
                           
	                 
}
	}

