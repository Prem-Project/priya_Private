package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class DemoSearchSteps {
	
	WebDriver driver=null;
	
	@Given("browser is open")
	public void browser_is_open() {
		
		System.out.println("browser is open successfully");
		String projectPath= System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectPath+"C:\\Users\\premj\\eclipse-workspace\\priyanka\\Drivers\\chromedriver.exe");
	    
		driver = new ChromeDriver();
		
		driver.navigate().to("https://demoqa.com/elements");
	}

	@Given("user clicks Textbox")
	public void user_clicks_textbox() {
		
		driver.findElement(By.id("item-0")).click();
		System.out.println("Successfully hits the Textbox field");
	   
	}

	@When("user enters a values in respective fields")
	public void user_enters_a_values_in_respective_fields() {
		
		driver.findElement(By.id("userName")).sendKeys("Priya");
		driver.findElement(By.id("userEmail")).sendKeys("Priya@gmail.com");
		driver.findElement(By.id("currentAddress")).sendKeys("coimbatore");
		driver.findElement(By.id("permanentAddress")).sendKeys("coimbatore");
		
        System.out.println("Successfully enters the data into the fields");
	   
	}

	@When("click submit")
	public void click_submit() {
	   
		driver.findElement(By.id("submit")).click();
		System.out.println("Successfully hits the submit button");
	}

	@Then("the user validate the search results")
	public void the_user_valoidate_the_search_results() {
		System.out.println("Successfully validate the search results");
	  
	}

}
