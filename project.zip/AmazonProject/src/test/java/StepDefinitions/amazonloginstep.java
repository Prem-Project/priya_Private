package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import driverinstance.driverinst;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectModel.Amazonpage;

public class amazonloginstep extends driverinst {

	
	@Given("Launch the Amazon Webpage")// Login is mapped in the hooks file
	public void launch_the_amazon_webpage()  {
		
		driver.findElement(By.xpath("//a[@id='nav-link-accountList']")).click();
	 }
	@When("the user enters the username")
	public void the_user_enters_the_username() {
		PageFactory.initElements(driver,Amazonpage.class);
		Amazonpage.Emailormobilephonenumber.sendKeys("priyasram373@gmail.com");
		Amazonpage.Continue.click();
	}
	@When("the user enters the password")
	public void the_user_enters_the_password() {
		Amazonpage.Password.sendKeys("Cucumber@373");
	}
	@And("the user click sigin button")
	public void the_user_click_sigin_button() {
		Amazonpage.Signin.click();
	}
	@Then("it should navigate to the search result page")
	public void it_should_navigate_to_the_search_result_page() {
		Amazonpage.searchBox.sendKeys("KOZDIKO Mini Magnetic Car Dashboard Mount Mobile Phone Holder with Metal Body Universal for Cars");
		driver.findElement(By.xpath("//*[@id='nav-search-submit-button']")).click();
	}
}

	


